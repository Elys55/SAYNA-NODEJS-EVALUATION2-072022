CREATE DATABASE  IF NOT EXISTS `formulaire`;
USE `formulaire`;

DROP TABLE IF EXISTS `form`;


CREATE TABLE `formulaire`.`form` ( 
`id` int NOT NULL AUTO_INCREMENT , 
`firstname` VARCHAR(55) DEFAULT NULL , 
`lastname` VARCHAR(55) DEFAULT NULL , 
`avis` text  ,
 `note` int  DEFAULT NULL , 
`formation` VARCHAR(55) NOT NULL , 
PRIMARY KEY (`id`)
) ENGINE = InnoDB; 
