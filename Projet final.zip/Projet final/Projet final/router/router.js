// const router = express.Router();

// Les routes
// router.get('/home', (req, res) => {
//     db.query(`SELECT formation,note,avis FROM form GROUP BY formation ORDER BY note DESC limit 4 `,
//         (err, res) => {
//             if (err) {
//                 res.status(500).render('erreur',{err:'erreur survenue!!!'});
//             } else {
//                 res.status(200).render('index', { result });
//             }
//         })
// })
//Ajout dans la base de données
// router.post('/form', (req, res) => {
//     let data = req.body;
//     db.query('INSERT INTO form SET ?',
//         data,
//         (err, res) => {
//             if (err) {
//                 res.status(500).render('erreur',{err:'erreur survenue!!!'});
//             } else {
//                 res.status(300).redirect('home');
//             }
//         })
// })

//avis backend
// router.get('/backend', (req, res) => {
//     let formation = req.params.formation;
//     db.query(`SELECT avis FROM form WHERE formation = 'Backend'`, [formation],
//         (err, res) => {
//             if (err) {
//                 res.status(500).render('erreur',{err:'erreur survenue!!!'});
//             } else {
//                 res.status(200).render('backend', { result });
//             }
//         })
// })
//avis frontend
// router.get('/frontend', (req, res) => {
//     let formation = req.params.formation;
//     db.query(`SELECT avis FROM form WHERE formation = 'Frontend'`, [formation], (err, result) => {
//         if (err) {
//             res.status(500).render('erreur',{err:'erreur survenue!!!'});
//         } else {
//             res.status(200).render('frontend', { result })
//         }
//     })
// })

//avis marketing
// router.get('/marketing', (req, res) => {
//     let formation = req.params.formation;
//     db.query(`SELECT avis FROM form WHERE formation = 'Marketing'`, [formation], (err, result) => {
//         if (err) {
//             res.status(500).render('erreur',{err:'erreur survenue!!!'});
//         } else {
//             res.status(200).render('Marketing', { result})
//         }

//     })
// })

//avis ux/ui
// router.get('/uxui', (req, res) => {
//     let formation = req.params.formation;
//             db.query(`SELECT avis FROM form WHERE formation = 'UX-UI'`, [formation], (err, result) => {
//                 if (err) {
//                     res.status(500).render('erreur',{err:'erreur survenue!!!'});
//                 } else {
//                     res.status(200).render('uxui', { result})
//                 }
//             })
//         })
//recupération des bd base de données
// module.exports = router;
