// $('#submitbtn').click(function(){

//     var firstname = ('#fname').val();
//     var lastname = ('#lname').val();
//     var avis = ('#avis').val();
//     var note = ('#note').val();
//     var formation = ('#formation').val();

//     $.post('/contact', {
//         firstname:firstname,
//         lastname:lastname,
//         avis:avis,
//         note:note,
//         formation:formation
//     },function(response){
//         $('#response').html('<div class="alert alert-success">'+response.message+'</div>')
//     })
// })

function insert(){
    $.ajax({
        url:'http://localhost:3000/contact',
        type:'POST',
        data:{
            fname: $("input[name=firstname]").val(),
            lname: $("input[name=lastname]").val(),
            avis: $("input[name=avis]").val(),
            note: $("input[name=note]").val(),
            formation: $("input[name=formation]").val(),
            action: 'insert'
        },
        success:function(response){
            if(response==1){
                alert("Data ajouté avec succes")
            }else if(response==2){
                alert("email is")
            }
        }
    })
}