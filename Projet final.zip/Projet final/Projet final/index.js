// Recuperation du module express, point d'entré
require('dotenv').config();
const express = require('express');
// const router = require('./router/router.js');
const con = require('./src/models/mysql')
const bodyParser = require('body-parser');

// Teste server
con.connect((err)=>{
    if(err) throw err;
    console.log("database connected...");
});
// utilisation des librairies
const app = express();
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());
// ajout des fichiers statiques
app.use(express.static("public"));
// Demarrage de l'instance express: c'est notre petit serveur web
const port = 3000;
// Point de terminaison
app.get('/',(req, res) => (res.send('Bonjour les gens, bienvenu sur la module API')))
app.listen(port,() => console.log('notre application est demarée en http://localhost:'+ port))
// Affichage index.html dans le navigateur
// Sign up
app.use(express.static(__dirname,''))
app.get("/signUp", (req, res)=>{
    res.sendFile(__dirname+"/views/signup.html");
});
// Home
app.use(express.static(__dirname,''))
app.get('/home', (req, res) => {
    res.sendFile(__dirname + '/index.html')
})
// parcours back-end
app.use(express.static(__dirname,''))
app.get("/backend", (req, res)=>{
    res.sendFile(__dirname+"/views/backend.html");
}); 
// parcours front-end
app.use(express.static(__dirname,''))
app.get("/frontend", (req, res)=>{
    res.sendFile(__dirname+"/views/frontend.html");
});
// parcours marketing-digital
app.use(express.static(__dirname,''))
app.get("/marketing", (req, res)=>{
    res.sendFile(__dirname+"/views/marketing.html");
});
// parcours UX/UI
app.get("/uxui", (req, res)=>{
    res.sendFile(__dirname+"/views/uxui.html");
});
// parcours contact
app.use(express.static(__dirname,''))
app.get("/contact", (req, res)=>{
    res.sendFile(__dirname+"/views/contact.html");
});

// connection a la bd
app.post('/contact', (req, res)=>{
    let firstname = req.body.fname,
        lastname = req.body.lname,
        avis = req.body.avis,
        note = req.body.note,
        formation= req.body.formation;
        req.getConnection((err, connection)=>{
            if(err){
                console.log(err);
            }else{
                let sql = 'INSERT INTO form (id, fname,lname,avis,note,formation) VALUES (?,?,?,?,?)';
                query = con.query(sql, [null,firstname,lastname,avis,note,formation], (err,result)=>{
                    if(err){
                        throw err;
                    }else{
                        res.status(200).render("index", (result))
                    }
                })
            }
        })
})
